<?php 
$i=0;
while ($i!=14) {
	$a[$i]=0;
	$i++;
}

 ?>