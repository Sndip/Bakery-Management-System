<?php
echo round(2.75);
echo floor(2.1);
echo ceil(2.75);
?>